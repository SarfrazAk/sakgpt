
import React, { useState, useRef, useEffect } from 'react';
import { MessageImage } from '../types';

interface ChatInputProps {
  onSend: (text: string, image?: MessageImage) => void;
  disabled: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSend, disabled }) => {
  const [text, setText] = useState('');
  const [selectedImage, setSelectedImage] = useState<MessageImage | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [text]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && window.innerWidth >= 768) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setSelectedImage({
          data: base64String,
          mimeType: file.type
        });
        setPreviewUrl(URL.createObjectURL(file));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = () => {
    if ((text.trim() || selectedImage) && !disabled) {
      onSend(text.trim(), selectedImage || undefined);
      setText('');
      removeImage();
    }
  };

  const toggleListening = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setText(prev => (prev ? prev + ' ' : '') + transcript);
    };

    recognition.start();
  };

  return (
    <div className="flex flex-col w-full gap-2">
      {previewUrl && (
        <div className="relative w-20 h-20 md:w-24 md:h-24 mb-1 md:mb-2 animate-in zoom-in duration-300">
          <img src={previewUrl} alt="Preview" className="w-full h-full object-cover rounded-lg md:rounded-xl border border-gray-700 shadow-lg" />
          <button 
            onClick={removeImage}
            className="absolute -top-1.5 -right-1.5 md:-top-2 md:-right-2 bg-gray-900 text-white rounded-full p-1 border border-gray-700 hover:bg-red-600 transition-colors shadow-xl"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      )}
      
      <div className="relative flex items-end w-full bg-[#161b22] border border-gray-700 rounded-2xl md:rounded-2xl shadow-2xl transition-all focus-within:border-blue-500/50 focus-within:ring-4 focus-within:ring-blue-500/10">
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleImageChange} 
          className="hidden" 
          accept="image/*"
        />
        
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled}
          className="p-3.5 md:p-4 text-gray-500 hover:text-blue-400 transition-colors shrink-0"
          title="Upload image"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
          </svg>
        </button>

        <button
          onClick={toggleListening}
          disabled={disabled}
          className={`p-3.5 md:p-4 transition-colors shrink-0 ${isListening ? 'text-red-500 animate-pulse' : 'text-gray-500 hover:text-red-400'}`}
          title="Voice input"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
          </svg>
        </button>

        <textarea
          ref={textareaRef}
          rows={1}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isListening ? "Listening..." : "Type or ask..."}
          disabled={disabled}
          className="flex-1 bg-transparent py-3.5 md:py-4 text-white placeholder-gray-500 resize-none outline-none custom-scrollbar max-h-32 md:max-h-48 text-[14px] md:text-[15px]"
        />
        
        <button
          onClick={handleSubmit}
          disabled={(!text.trim() && !selectedImage) || disabled}
          className={`m-2 md:m-2.5 p-2 rounded-xl transition-all shrink-0 ${
            (text.trim() || selectedImage) && !disabled 
              ? 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg active:scale-95' 
              : 'bg-gray-800 text-gray-600 cursor-not-allowed'
          }`}
        >
          {disabled ? (
            <svg className="w-5 h-5 animate-spin" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
            </svg>
          )}
        </button>
      </div>
    </div>
  );
};

export default ChatInput;
