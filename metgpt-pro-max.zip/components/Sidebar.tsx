import React from 'react';
import { ChatSession, User } from '../types';
import Logo from './Logo';

interface SidebarProps {
  sessions: ChatSession[];
  currentId: string | null;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onNewChat: () => void;
  user: User;
  onLogout: () => void;
  onUpgradeRequest: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ sessions, currentId, onSelect, onDelete, onNewChat, user, onLogout, onUpgradeRequest }) => (
  <div className="flex flex-col h-full overflow-hidden">
    <div className="p-6 flex items-center gap-3 border-b border-gray-800 bg-black/20">
      <Logo className="w-8 h-8" />
      <div className="flex flex-col">
        <span className="font-black text-white tracking-tighter">MetGPT</span>
        <span className="text-[10px] text-cyan-500 font-bold uppercase tracking-widest">Neural Pro</span>
      </div>
    </div>
    <div className="p-4 flex-1 overflow-y-auto space-y-2">
      <button onClick={onNewChat} className="w-full flex items-center gap-3 p-3 bg-cyan-600/10 text-cyan-500 rounded-xl hover:bg-cyan-600 hover:text-white transition-all font-bold text-sm mb-4">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
        New Neural Session
      </button>
      {sessions.map(s => (
        <div key={s.id} onClick={() => onSelect(s.id)} className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer border transition-all ${currentId === s.id ? 'bg-gray-800 border-gray-700 text-white' : 'border-transparent text-gray-500 hover:text-gray-300 hover:bg-gray-800/50'}`}>
          <span className="text-sm truncate pr-2">{s.title}</span>
          <button onClick={(e) => { e.stopPropagation(); onDelete(s.id); }} className="opacity-0 group-hover:opacity-100 text-gray-600 hover:text-red-500"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
        </div>
      ))}
    </div>
    <div className="p-4 border-t border-gray-800 bg-black/20">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-600 to-indigo-700 flex items-center justify-center font-black">{user.name[0]}</div>
        <div className="flex-1 overflow-hidden">
          <p className="text-sm font-bold truncate">{user.name}</p>
          <p className="text-[10px] text-gray-500 uppercase font-black">{user.tier} member</p>
        </div>
        <button onClick={onLogout} className="text-gray-500 hover:text-red-500"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg></button>
      </div>
      {user.tier === 'free' && <button onClick={onUpgradeRequest} className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-lg">Upgrade to Pro</button>}
    </div>
  </div>
);
export default Sidebar;