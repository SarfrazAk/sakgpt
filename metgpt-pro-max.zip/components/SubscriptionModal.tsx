
import React, { useState } from 'react';
import Logo from './Logo';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: () => void;
}

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ isOpen, onClose, onUpgrade }) => {
  const [step, setStep] = useState<'offer' | 'payment' | 'processing' | 'verify'>('offer');
  const [region, setRegion] = useState<'PK' | 'INT'>('PK');
  const [paymentMethod, setPaymentMethod] = useState<'easypaisa' | 'card' | null>(null);
  const [trxId, setTrxId] = useState('');

  // SAKIB'S ACTUAL PAYMENT DETAILS
  const EASYPAISA_NUMBER = "03093193703"; 
  const NAYAPAY_NUMBER = "03163292606";
  const ACCOUNT_NAME = "SAKIB ENTERPRISE";

  if (!isOpen) return null;

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('processing');
    setTimeout(() => {
      onUpgrade();
      onClose();
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" onClick={onClose}></div>
      
      <div className="relative w-full max-w-lg bg-[#0d1117] border border-gray-800 rounded-[2.5rem] overflow-hidden shadow-[0_0_100px_rgba(34,211,238,0.1)] animate-in zoom-in duration-300">
        
        {/* Region Switcher */}
        {step === 'offer' && (
          <div className="flex justify-center mt-8">
            <div className="bg-gray-900 p-1 rounded-2xl border border-gray-800 flex gap-1">
              <button 
                onClick={() => setRegion('PK')}
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${region === 'PK' ? 'bg-cyan-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}
              >
                🇵🇰 Pakistan
              </button>
              <button 
                onClick={() => setRegion('INT')}
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${region === 'INT' ? 'bg-cyan-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}
              >
                🌍 Global
              </button>
            </div>
          </div>
        )}

        {step === 'offer' && (
          <div className="p-8 md:p-12 text-center">
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-cyan-500/10 rounded-full animate-pulse">
                <Logo className="w-16 h-16" />
              </div>
            </div>
            <h2 className="text-3xl font-black text-white mb-2 tracking-tight uppercase italic">Neural Pro Max</h2>
            <p className="text-gray-400 mb-8 font-medium">Unleash the full SakGPT architecture.</p>
            
            <div className="grid grid-cols-1 gap-4 mb-10 text-left">
              {[
                'Gemini 3 Pro High-Reasoning Engine',
                'Unlimited 4K Image Synthesis',
                'Advanced Web Intelligence Access',
                'Priority Neural Processing Speed'
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-3 bg-gray-900/40 p-3 rounded-2xl border border-gray-800/50">
                  <div className="w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center shrink-0">
                    <svg className="w-3.5 h-3.5 text-cyan-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-300 text-xs font-bold tracking-tight">{feature}</span>
                </div>
              ))}
            </div>

            <div className="bg-gradient-to-r from-gray-900 to-black rounded-3xl p-6 mb-8 border border-gray-800 shadow-inner">
              <div className="flex justify-between items-center">
                <span className="text-gray-600 font-black uppercase tracking-widest text-[10px]">Tier Access</span>
                <span className="text-3xl font-black text-white italic">
                  {region === 'PK' ? '500 PKR' : '$5.00 USD'}
                  <span className="text-[10px] text-gray-500 ml-2 not-italic font-medium uppercase tracking-tighter">/ Monthly</span>
                </span>
              </div>
            </div>

            <button 
              onClick={() => setStep('payment')}
              className="w-full py-5 bg-white text-black font-black rounded-3xl hover:bg-cyan-50 transition-all shadow-[0_20px_40px_rgba(255,255,255,0.1)] active:scale-95 uppercase tracking-widest text-sm"
            >
              Continue to Secure Checkout
            </button>
          </div>
        )}

        {step === 'payment' && (
          <div className="p-8 md:p-12">
            <h3 className="text-xl font-black text-white mb-8 flex items-center gap-3">
              <span className="w-2 h-8 bg-cyan-600 rounded-full"></span>
              Payment Gateway
            </h3>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-3">
                {region === 'PK' && (
                  <button 
                    onClick={() => { setPaymentMethod('easypaisa'); setStep('verify'); }}
                    className="flex items-center justify-between p-6 bg-green-600/10 rounded-3xl border border-green-500/30 hover:bg-green-600/20 transition-all group"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-green-600 rounded-2xl flex items-center justify-center font-black text-white shadow-lg shadow-green-900/40">EP</div>
                      <div className="text-left">
                        <span className="block text-sm font-black text-white uppercase tracking-wider">EasyPaisa</span>
                        <span className="text-[10px] text-green-500/80 font-bold uppercase tracking-widest italic">Fast Local Transfer</span>
                      </div>
                    </div>
                    <svg className="w-6 h-6 text-green-500 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                  </button>
                )}

                <button 
                  onClick={() => { setPaymentMethod('card'); setStep('verify'); }}
                  className="flex items-center justify-between p-6 bg-blue-600/10 rounded-3xl border border-blue-500/30 hover:bg-blue-600/20 transition-all group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center font-black text-white shadow-lg shadow-blue-900/40">CC</div>
                    <div className="text-left">
                      <span className="block text-sm font-black text-white uppercase tracking-wider">Card / NayaPay</span>
                      <span className="text-[10px] text-blue-500/80 font-bold uppercase tracking-widest italic">Global Secure Gateway</span>
                    </div>
                  </div>
                  <svg className="w-6 h-6 text-blue-500 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                </button>
              </div>

              <button 
                onClick={() => setStep('offer')}
                className="w-full py-4 text-gray-600 text-[10px] font-black uppercase tracking-[0.3em] mt-4"
              >
                Change Package Plan
              </button>
            </div>
          </div>
        )}

        {step === 'verify' && paymentMethod === 'easypaisa' && (
          <div className="p-8 md:p-12 animate-in slide-in-from-right-4 duration-500">
            <h3 className="text-xl font-black text-white mb-6 uppercase italic">EasyPaisa Transfer</h3>
            
            <div className="bg-gray-900 rounded-[2rem] p-8 border border-gray-800 mb-8 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/5 blur-3xl rounded-full"></div>
               <div className="relative z-10 space-y-6">
                  <div>
                    <label className="text-[10px] text-gray-600 font-black uppercase tracking-widest block mb-1">EasyPaisa Number</label>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-black text-white tracking-tighter">{EASYPAISA_NUMBER}</span>
                      <button onClick={() => navigator.clipboard.writeText(EASYPAISA_NUMBER)} className="text-[10px] bg-green-600/20 text-green-500 px-3 py-1 rounded-full font-black uppercase tracking-widest hover:bg-green-600 hover:text-white transition-all">Copy</button>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-600 font-black uppercase tracking-widest block mb-1">Account Owner</label>
                    <span className="text-lg font-bold text-gray-400">{ACCOUNT_NAME}</span>
                  </div>
                  <div className="pt-4 border-t border-gray-800">
                    <p className="text-[11px] text-gray-500 leading-relaxed">Please send <strong className="text-white">500 PKR</strong> to this account and enter the <strong className="text-white">Transaction ID (TID)</strong> below.</p>
                  </div>
               </div>
            </div>

            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              <input 
                type="text" 
                required 
                value={trxId}
                onChange={(e) => setTrxId(e.target.value)}
                placeholder="Enter Transaction ID (TID)" 
                className="w-full bg-black/60 border border-gray-800 rounded-2xl px-6 py-4 text-white placeholder-gray-700 outline-none focus:border-green-500/50 transition-all font-mono" 
              />
              <button className="w-full py-5 bg-green-600 text-white font-black rounded-3xl hover:bg-green-500 transition-all shadow-xl shadow-green-900/40 uppercase tracking-widest">Verify & Activate Pro</button>
              <button type="button" onClick={() => setStep('payment')} className="w-full py-2 text-gray-600 text-[10px] font-black uppercase tracking-widest">Back</button>
            </form>
          </div>
        )}

        {step === 'verify' && paymentMethod === 'card' && (
           <div className="p-8 md:p-12 animate-in slide-in-from-right-4 duration-500">
             <h3 className="text-xl font-black text-white mb-6 uppercase italic">Global Payment</h3>
             
             <div className="bg-gradient-to-br from-blue-900/20 to-indigo-900/20 p-6 rounded-[2rem] border border-blue-500/20 mb-6">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] text-blue-400 font-black uppercase tracking-widest">NayaPay Secure</span>
                  <div className="flex gap-2">
                    <div className="w-8 h-5 bg-white/10 rounded"></div>
                    <div className="w-8 h-5 bg-white/10 rounded"></div>
                  </div>
                </div>
                <div className="mb-4">
                   <label className="text-[9px] text-gray-500 font-black uppercase block mb-1">Reference Account</label>
                   <span className="text-lg font-mono text-white tracking-widest">{NAYAPAY_NUMBER}</span>
                </div>
                <div className="text-[11px] text-gray-400 leading-relaxed italic">
                  International users: Transfer <strong className="text-white">$5.00 USD</strong> or equivalent to our verified NayaPay node.
                </div>
             </div>

             <form onSubmit={handlePaymentSubmit} className="space-y-4">
               <div className="space-y-4">
                 <input type="text" placeholder="Cardholder Name" className="w-full bg-black/60 border border-gray-800 rounded-2xl px-6 py-4 text-white placeholder-gray-700 outline-none focus:border-blue-500/50" />
                 <input type="text" placeholder="Card Number" className="w-full bg-black/60 border border-gray-800 rounded-2xl px-6 py-4 text-white placeholder-gray-700 outline-none focus:border-blue-500/50" />
                 <div className="grid grid-cols-2 gap-4">
                   <input type="text" placeholder="MM / YY" className="w-full bg-black/60 border border-gray-800 rounded-2xl px-6 py-4 text-white placeholder-gray-700 outline-none" />
                   <input type="password" placeholder="CVC" className="w-full bg-black/60 border border-gray-800 rounded-2xl px-6 py-4 text-white placeholder-gray-700 outline-none" />
                 </div>
               </div>
               <button className="w-full py-5 bg-blue-600 text-white font-black rounded-3xl hover:bg-blue-500 transition-all shadow-xl shadow-blue-900/40 uppercase tracking-widest mt-4">
                 Confirm {region === 'PK' ? '500 PKR' : '$5.00 USD'}
               </button>
               <button type="button" onClick={() => setStep('payment')} className="w-full py-2 text-gray-600 text-[10px] font-black uppercase tracking-widest">Back</button>
             </form>
           </div>
        )}

        {step === 'processing' && (
          <div className="p-12 text-center py-24 animate-in fade-in duration-500">
            <div className="relative w-24 h-24 mx-auto mb-10">
              <div className="absolute inset-0 border-[6px] border-gray-800 rounded-full"></div>
              <div className="absolute inset-0 border-[6px] border-cyan-500 rounded-full border-t-transparent animate-spin"></div>
              <div className="absolute inset-4 bg-cyan-500/10 rounded-full flex items-center justify-center">
                <Logo className="w-8 h-8 opacity-50" />
              </div>
            </div>
            <h3 className="text-2xl font-black text-white mb-3 tracking-tighter italic uppercase">Neural Handshake...</h3>
            <p className="text-gray-500 text-sm font-medium">Verifying transfer to {paymentMethod === 'easypaisa' ? 'EasyPaisa' : 'NayaPay'} network.</p>
            <div className="mt-8 px-8">
              <div className="h-1.5 w-full bg-gray-900 rounded-full overflow-hidden">
                <div className="h-full bg-cyan-500 animate-[loading_4s_ease-in-out]"></div>
              </div>
            </div>
            <style>{`
              @keyframes loading {
                0% { width: 0%; }
                100% { width: 100%; }
              }
            `}</style>
          </div>
        )}
      </div>
    </div>
  );
};

export default SubscriptionModal;
