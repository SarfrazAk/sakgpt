import React, { useState } from 'react';
import Logo from './Logo';
import { SubscriptionTier, Agent, LanguageCode, Language } from '../types';

const LANGUAGES: Language[] = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'ur', name: 'Urdu', flag: '🇵🇰' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  { code: 'pt', name: 'Portuguese', flag: '🇧🇷' },
];

interface HeaderProps {
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  title: string;
  tier?: SubscriptionTier;
  activeAgent?: Agent;
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
}

const Header: React.FC<HeaderProps> = ({ isSidebarOpen, toggleSidebar, title, tier, activeAgent, currentLanguage, onLanguageChange }) => {
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const selectedLang = LANGUAGES.find(l => l.code === currentLanguage) || LANGUAGES[0];

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'MetGPT Pro Max',
          text: 'Check out this amazing AI app!',
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        alert('Link copied to clipboard!');
      }
    } catch (error) {
      console.log('Sharing failed', error);
    }
  };

  return (
    <header className="h-16 flex items-center px-3 md:px-6 border-b border-gray-800 bg-[#0b0e14]/80 backdrop-blur-md sticky top-0 z-30 justify-between shrink-0 safe-top">
      <div className="flex items-center gap-2 md:gap-4 overflow-hidden">
        <button 
          onClick={toggleSidebar}
          className="p-2 hover:bg-gray-800 rounded-lg transition-colors text-gray-400 shrink-0"
          aria-label="Toggle Sidebar"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <div className="flex items-center gap-2 overflow-hidden">
          <Logo className="w-6 h-6 hidden xs:block" />
          <div className="flex flex-col min-w-0">
            <h1 className="text-sm md:text-md font-bold text-white truncate max-w-[120px] xs:max-w-[180px] sm:max-w-md tracking-tight leading-none mb-0.5">
              {title}
            </h1>
            {activeAgent && (
              <span className="text-[9px] text-cyan-500 font-black uppercase tracking-widest flex items-center gap-1">
                {activeAgent.icon} {activeAgent.name}
              </span>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-1.5 md:gap-3 shrink-0">
        <button 
          onClick={handleShare}
          className="p-2 bg-gray-800/40 hover:bg-gray-800 border border-gray-700 rounded-xl transition-all text-gray-400 hover:text-white"
          title="Share App"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
          </svg>
        </button>

        <div className="relative">
          <button 
            onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
            className="flex items-center gap-1.5 px-2 py-1.5 md:px-3 md:py-1.5 bg-gray-800/40 hover:bg-gray-800 border border-gray-700 rounded-xl transition-all group"
          >
            <span className="text-lg md:text-xl">{selectedLang.flag}</span>
            <span className="text-[10px] md:text-xs font-black uppercase tracking-tighter text-gray-400 group-hover:text-white hidden sm:block">{selectedLang.code}</span>
            <svg className={`w-3 h-3 text-gray-600 transition-transform ${isLangMenuOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>

          {isLangMenuOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setIsLangMenuOpen(false)}></div>
              <div className="absolute right-0 mt-2 w-44 bg-[#161b22] border border-gray-800 rounded-2xl shadow-2xl py-2 z-50 animate-in fade-in zoom-in duration-200">
                <div className="px-3 py-2 border-b border-gray-800 mb-2">
                  <span className="text-[9px] font-black text-gray-500 uppercase tracking-[0.2em]">Language</span>
                </div>
                <div className="max-h-[260px] overflow-y-auto custom-scrollbar">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        onLanguageChange(lang.code);
                        setIsLangMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-4 py-2.5 text-left transition-colors ${
                        currentLanguage === lang.code ? 'bg-cyan-600/10 text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-lg">{lang.flag}</span>
                        <span className="text-xs font-bold">{lang.name}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        <div className={`hidden xs:flex items-center gap-1.5 px-3 py-1 rounded-full border transition-all ${
          tier === 'pro' 
            ? 'bg-gradient-to-r from-cyan-600/20 to-indigo-600/20 border-cyan-500/30' 
            : 'bg-gray-800/40 border-gray-700'
        }`}>
          <span className={`w-1 h-1 rounded-full animate-pulse ${tier === 'pro' ? 'bg-cyan-400' : 'bg-gray-500'}`}></span>
          <span className={`text-[9px] font-black uppercase tracking-tighter ${tier === 'pro' ? 'text-cyan-400' : 'text-gray-500'}`}>
            {tier === 'pro' ? 'Pro' : 'Free'}
          </span>
        </div>
      </div>
    </header>
  );
};

export default Header;