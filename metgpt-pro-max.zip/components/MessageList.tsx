import React, { useEffect, useRef, useState } from 'react';
import { Message, Role } from '../types';
import MarkdownRenderer from './MarkdownRenderer';
import { geminiService } from '../services/geminiService';

interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
}

const MessageList: React.FC<MessageListProps> = ({ messages, isLoading }) => {
  const bottomRef = useRef<HTMLDivElement>(null);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleDownload = (data: string, mime: string) => {
    const link = document.createElement('a');
    link.href = `data:${mime};base64,${data}`;
    link.download = `metgpt-neural-art-${Date.now()}.png`;
    link.click();
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const stopAudio = () => {
    if (sourceNodeRef.current) {
      sourceNodeRef.current.stop();
      sourceNodeRef.current = null;
    }
    setPlayingId(null);
  };

  const handleSpeak = async (message: Message) => {
    if (playingId === message.id) {
      stopAudio();
      return;
    }

    stopAudio();
    setPlayingId(message.id);

    try {
      const audioBytes = await geminiService.textToSpeech(message.content);
      
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      
      const ctx = audioContextRef.current;
      const audioBuffer = await decodeAudioData(audioBytes, ctx, 24000, 1);
      
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.onended = () => setPlayingId(null);
      
      sourceNodeRef.current = source;
      source.start();
    } catch (error) {
      console.error("Audio playback error:", error);
      setPlayingId(null);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar px-3 md:px-4">
      <div className="max-w-4xl mx-auto py-6 md:py-12 space-y-8 md:space-y-16">
        {messages.map((message) => (
          <div key={message.id} className="animate-in fade-in slide-in-from-bottom-2 duration-500">
            <div className="flex gap-3 md:gap-10">
              <div className={`w-8 h-8 md:w-10 md:h-10 rounded-xl md:rounded-2xl flex items-center justify-center shrink-0 shadow-lg ${
                message.role === Role.ASSISTANT 
                  ? 'bg-gradient-to-br from-cyan-600 to-indigo-700 ring-4 ring-cyan-500/10' 
                  : 'bg-gray-800 border border-gray-700'
              }`}>
                {message.role === Role.ASSISTANT ? (
                  <svg className="w-4 h-4 md:w-6 md:h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                ) : (
                  <span className="text-[8px] md:text-[11px] font-black text-gray-500">PRO</span>
                )}
              </div>
              <div className="flex-1 min-w-0 space-y-2 md:space-y-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                     <span className="text-[9px] md:text-[11px] font-black text-gray-500 uppercase tracking-[0.1em] md:tracking-[0.2em] truncate">
                      {message.role === Role.ASSISTANT ? 'MetGPT AI' : 'Command'}
                    </span>
                    <div className="h-1 w-1 bg-gray-800 rounded-full shrink-0"></div>
                    <span className="text-[9px] md:text-[11px] text-gray-700 font-medium shrink-0">
                      {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  {message.role === Role.ASSISTANT && message.content && (
                    <button 
                      onClick={() => handleSpeak(message)}
                      className={`flex items-center gap-2 px-3 py-1 rounded-full border transition-all ${
                        playingId === message.id 
                        ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-400' 
                        : 'bg-gray-800/50 border-gray-700 text-gray-500 hover:text-white hover:border-gray-500'
                      }`}
                    >
                      {playingId === message.id ? (
                        <>
                          <div className="flex items-center gap-0.5 h-3">
                            <div className="w-0.5 h-full bg-cyan-400 animate-[pulse_0.6s_ease-in-out_infinite]"></div>
                            <div className="w-0.5 h-1/2 bg-cyan-400 animate-[pulse_0.8s_ease-in-out_infinite]"></div>
                            <div className="w-0.5 h-3/4 bg-cyan-400 animate-[pulse_0.4s_ease-in-out_infinite]"></div>
                          </div>
                          <span className="text-[9px] font-black uppercase tracking-widest">Speaking</span>
                        </>
                      ) : (
                        <>
                          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                          </svg>
                          <span className="text-[9px] font-black uppercase tracking-widest">Listen</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
                
                <div className="text-gray-200 leading-relaxed text-[14px] md:text-[17px]">
                  {message.image && (
                    <div className="mb-4 md:mb-6 group relative max-w-full md:max-w-2xl rounded-xl md:rounded-[2rem] overflow-hidden border border-gray-800 shadow-xl bg-black/20">
                      <img 
                        src={`data:${message.image.mimeType};base64,${message.image.data}`} 
                        alt="Visual Output" 
                        className="w-full h-auto object-contain transition-transform duration-700 lg:group-hover:scale-[1.02]"
                      />
                      <div className="absolute top-2 right-2 md:top-4 md:right-4 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => handleDownload(message.image!.data, message.image!.mimeType)}
                          className="p-2 md:p-3 bg-black/60 backdrop-blur-md rounded-xl md:rounded-2xl text-white hover:bg-cyan-600 transition-all border border-white/10"
                        >
                          <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  )}
                  
                  <div className={message.content ? 'block' : 'hidden'}>
                    <MarkdownRenderer content={message.content} />
                  </div>
                  
                  {message.role === Role.ASSISTANT && message.content === '' && !message.image && (
                    <div className="flex gap-1.5 items-center py-4 md:py-6">
                      <div className="w-1.5 h-1.5 md:w-2.5 md:h-2.5 bg-cyan-500 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 md:w-2.5 md:h-2.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:200ms]"></div>
                      <div className="w-1.5 h-1.5 md:w-2.5 md:h-2.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:400ms]"></div>
                    </div>
                  )}

                  {message.sources && message.sources.length > 0 && (
                    <div className="mt-6 md:mt-10 pt-4 md:pt-8 border-t border-gray-800/80">
                      <div className="flex items-center gap-2 mb-2 md:mb-4">
                        <span className="text-[9px] md:text-[11px] font-black text-gray-500 uppercase tracking-widest">Research Data</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {Array.from(new Set(message.sources.map(s => s.uri))).map(uri => {
                          const source = message.sources?.find(s => s.uri === uri);
                          return (
                            <a 
                              key={uri} 
                              href={uri} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="group text-[10px] md:text-[12px] px-3 py-1.5 bg-gray-800/30 hover:bg-cyan-600/10 border border-gray-800 rounded-lg md:rounded-xl text-gray-400 hover:text-cyan-400 transition-all flex items-center gap-1.5 max-w-[180px] md:max-w-[240px]"
                            >
                              <span className="truncate">{source?.title || 'Source'}</span>
                              <svg className="w-3 h-3 shrink-0 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                              </svg>
                            </a>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
        <div ref={bottomRef} className="h-12 md:h-1" />
      </div>
    </div>
  );
};

export default MessageList;