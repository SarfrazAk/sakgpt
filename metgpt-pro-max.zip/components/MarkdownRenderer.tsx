
import React from 'react';

interface MarkdownRendererProps {
  content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const parseContent = (text: string) => {
    let html = text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

    // Code Blocks
    html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, '<div class="relative group my-6"><div class="absolute -top-3 left-4 px-2 py-0.5 bg-gray-800 text-[10px] font-mono text-gray-500 rounded uppercase tracking-wider">$1</div><pre class="bg-[#0d1117] rounded-xl p-5 overflow-x-auto border border-gray-800 font-mono text-sm leading-relaxed"><code>$2</code></pre></div>');

    // Inline Code
    html = html.replace(/`([^`]+)`/g, '<code class="bg-gray-800/80 px-1.5 py-0.5 rounded text-blue-300 font-mono text-sm">$1</code>');

    // Bold
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong class="font-bold text-white">$1</strong>');
    
    // Italic
    html = html.replace(/\*([^*]+)\*/g, '<em class="italic text-gray-300">$1</em>');

    // Headers
    html = html.replace(/^### (.*$)/gm, '<h3 class="text-lg font-bold text-white mt-8 mb-3">$1</h3>');
    html = html.replace(/^## (.*$)/gm, '<h2 class="text-xl font-bold text-white mt-10 mb-4 border-b border-gray-800 pb-2">$1</h2>');
    html = html.replace(/^# (.*$)/gm, '<h1 class="text-2xl font-bold text-white mt-12 mb-6 tracking-tight">$1</h1>');

    // Lists
    html = html.replace(/^\s*[-*] (.*$)/gm, '<li class="ml-6 list-disc mb-2 pl-2">$1</li>');
    html = html.replace(/(<li class="ml-6 list-disc mb-2 pl-2">.*<\/li>)+/g, '<ul class="my-6 space-y-1">$0</ul>');

    html = html.replace(/^\s*\d+\. (.*$)/gm, '<li class="ml-6 list-decimal mb-2 pl-2">$1</li>');
    html = html.replace(/(<li class="ml-6 list-decimal mb-2 pl-2">.*<\/li>)+/g, '<ol class="my-6 space-y-1">$0</ol>');

    // Paragraphs - improved logic to avoid double wrapping
    const sections = html.split(/\n\n+/);
    return sections.map(section => {
      if (section.trim().startsWith('<') || section.trim().length === 0) return section;
      return `<p class="mb-5 leading-relaxed">${section.replace(/\n/g, '<br />')}</p>`;
    }).join('');
  };

  return (
    <div 
      className="prose prose-invert max-w-none" 
      dangerouslySetInnerHTML={{ __html: parseContent(content) }} 
    />
  );
};

export default MarkdownRenderer;
