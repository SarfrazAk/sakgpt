
import React from 'react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = "w-12 h-12" }) => {
  return (
    <svg 
      className={className} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Vibrant Core Gradient */}
        <linearGradient id="sak-gradient-main" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#22d3ee" /> {/* Cyan 400 */}
          <stop offset="50%" stopColor="#818cf8" /> {/* Indigo 400 */}
          <stop offset="100%" stopColor="#c084fc" /> {/* Purple 400 */}
        </linearGradient>

        {/* Secondary Shimmer Gradient */}
        <linearGradient id="sak-shimmer" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="white" stopOpacity="0" />
          <stop offset="50%" stopColor="white" stopOpacity="0.6" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </linearGradient>

        {/* Inner Glow and Depth Filters */}
        <filter id="sak-bloom" x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="sak-inner-shadow">
          <feOffset dx="0" dy="2" />
          <feGaussianBlur stdDeviation="2" result="offset-blur" />
          <feComposite operator="out" in="SourceGraphic" in2="offset-blur" result="inverse" />
          <feFlood floodColor="black" floodOpacity="0.5" result="color" />
          <feComposite operator="in" in="color" in2="inverse" result="shadow" />
          <feComposite operator="over" in="shadow" in2="SourceGraphic" />
        </filter>

        <style>
          {`
            @keyframes shimmer-move {
              0% { transform: translateX(-100%) skewX(-20deg); }
              100% { transform: translateX(200%) skewX(-20deg); }
            }
            @keyframes pulse-core {
              0%, 100% { opacity: 0.8; r: 5; }
              50% { opacity: 1; r: 8; }
            }
            @keyframes float-node {
              0%, 100% { transform: translateY(0); }
              50% { transform: translateY(-3px); }
            }
            .shimmer-rect {
              animation: shimmer-move 3s infinite ease-in-out;
            }
            .core-pulse {
              animation: pulse-core 2s infinite ease-in-out;
            }
            .node-float {
              animation: float-node 4s infinite ease-in-out;
            }
          `}
        </style>

        <mask id="sak-mask">
          <path 
            d="M70 25 C 70 25, 30 20, 30 40 C 30 55, 70 45, 70 60 C 70 75, 30 75, 30 75" 
            stroke="white" 
            strokeWidth="14" 
            strokeLinecap="round" 
            fill="none"
          />
        </mask>
      </defs>
      
      {/* Background Glow */}
      <circle cx="50" cy="50" r="45" fill="url(#sak-gradient-main)" fillOpacity="0.1" filter="url(#sak-bloom)" />
      
      {/* Structural S Ribbon - Glass Effect */}
      <path 
        d="M70 25 C 70 25, 30 20, 30 40 C 30 55, 70 45, 70 60 C 70 75, 30 75, 30 75" 
        stroke="url(#sak-gradient-main)" 
        strokeWidth="14" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        filter="url(#sak-bloom)"
      />

      {/* Internal Shimmer Scanning Effect */}
      <g mask="url(#sak-mask)">
        <rect 
          x="-50" y="0" width="50" height="100" 
          fill="url(#sak-shimmer)" 
          className="shimmer-rect"
        />
      </g>

      {/* Precision Highlights */}
      <path 
        d="M65 28 C 65 28, 35 24, 35 38" 
        stroke="white" 
        strokeWidth="2" 
        strokeLinecap="round" 
        opacity="0.5"
      />
      <path 
        d="M35 72 C 35 72, 65 72, 65 62" 
        stroke="white" 
        strokeWidth="2" 
        strokeLinecap="round" 
        opacity="0.3"
      />

      {/* Central Neural Core Node */}
      <circle 
        cx="50" cy="50" r="6" 
        fill="white" 
        className="core-pulse"
        filter="url(#sak-bloom)"
      />
      
      {/* Connectivity Nodes */}
      <circle cx="70" cy="25" r="4" fill="white" className="node-float" />
      <circle cx="30" cy="75" r="4" fill="white" style={{ animationDelay: '1s' }} className="node-float" />
      
      {/* Peripheral Circuit Elements */}
      <path d="M50 10 L50 18" stroke="url(#sak-gradient-main)" strokeWidth="1" strokeOpacity="0.4" />
      <path d="M50 82 L50 90" stroke="url(#sak-gradient-main)" strokeWidth="1" strokeOpacity="0.4" />
      <path d="M10 50 L18 50" stroke="url(#sak-gradient-main)" strokeWidth="1" strokeOpacity="0.4" />
      <path d="M82 50 L90 50" stroke="url(#sak-gradient-main)" strokeWidth="1" strokeOpacity="0.4" />
    </svg>
  );
};

export default Logo;
