import { GoogleGenAI, GenerateContentResponse, Modality } from "@google/genai";
import { Message, Role, GroundingSource, MessageImage, SubscriptionTier, AgentType, LanguageCode } from "../types";

const AGENT_INSTRUCTIONS: Record<AgentType, string> = {
  core: `You are MetGPT Universal Core. A highly intelligent, empathetic, and helpful AI assistant powered by Google's Gemini model. Maintain a professional yet warm tone. Always use Markdown for formatting.`,
  researcher: `You are the MetGPT Cyber Researcher. Your goal is to provide accurate and up-to-date information using real-time web search. State facts clearly and provide citations.`,
  designer: `You are the MetGPT Nexus Designer. You specialize in visual arts and creative prompts. Describe images with extreme detail for generation tasks.`,
  coder: `You are the MetGPT Bit Architect. Provide expert-level code, explain logic clearly, and follow security best practices.`,
  analyst: `You are the MetGPT Neural Analyst. Focus on logic, data tables, and mathematical precision.`
};

const LANGUAGE_NAMES: Record<LanguageCode, string> = {
  en: 'English', ur: 'Urdu', ar: 'Arabic', es: 'Spanish', fr: 'French', 
  de: 'German', hi: 'Hindi', zh: 'Chinese', ja: 'Japanese', ru: 'Russian', pt: 'Portuguese'
};

export interface StreamResult {
  text: string;
  sources?: GroundingSource[];
  generatedImage?: MessageImage;
}

export class GeminiService {
  private getAI() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }

  isImageGenerationIntent(text: string): boolean {
    const keywords = ['generate image', 'create image', 'draw', 'paint', 'make a picture', 'image of', 'photo of'];
    const lowerText = text.toLowerCase();
    return keywords.some(k => lowerText.includes(k));
  }

  async generateImage(prompt: string, aspectRatio: string = "1:1"): Promise<MessageImage> {
    const ai = this.getAI();
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: prompt }] },
        config: { imageConfig: { aspectRatio: aspectRatio as any } }
      });

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            return { data: part.inlineData.data, mimeType: part.inlineData.mimeType };
          }
        }
      }
      throw new Error("No image data found");
    } catch (error) {
      console.error("Image generation error:", error);
      throw error;
    }
  }

  async *streamChat(history: Message[], userInput: string, tier: SubscriptionTier = 'free', agentId: AgentType = 'core', lang: LanguageCode = 'en') {
    const ai = this.getAI();
    const contents = history.map(msg => ({
      role: msg.role === Role.USER ? 'user' : 'model',
      parts: msg.image && msg.role === Role.USER 
        ? [{ text: msg.content || ' ' }, { inlineData: { data: msg.image.data, mimeType: msg.image.mimeType } }]
        : [{ text: msg.content || ' ' }]
    }));

    const model = tier === 'pro' ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
    const languageInstruction = `SYSTEM: You MUST respond in ${LANGUAGE_NAMES[lang]}. This is non-negotiable.`;

    const stream = await ai.models.generateContentStream({
      model: model,
      contents: contents,
      config: {
        systemInstruction: `${AGENT_INSTRUCTIONS[agentId]}\n\n${languageInstruction}`,
        tools: [{ googleSearch: {} }],
        temperature: 0.7,
        thinkingConfig: { thinkingBudget: tier === 'pro' ? 16000 : 0 } 
      },
    });

    let fullSources: GroundingSource[] = [];
    for await (const chunk of stream) {
      const response = chunk as GenerateContentResponse;
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        chunks.forEach((c: any) => {
          if (c.web) fullSources.push({ title: c.web.title || 'Source', uri: c.web.uri });
        });
      }
      yield { text: response.text || '', sources: fullSources.length > 0 ? fullSources : undefined } as StreamResult;
    }
  }

  async textToSpeech(text: string, voiceName: string = 'Kore'): Promise<Uint8Array> {
    const ai = this.getAI();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } },
      },
    });
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) throw new Error("No audio data");
    return this.decodeBase64(base64Audio);
  }

  private decodeBase64(base64: string): Uint8Array {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  }

  async generateTitle(firstMessage: string, lang: LanguageCode = 'en'): Promise<string> {
    const ai = this.getAI();
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Provide a 2-word title for this in ${LANGUAGE_NAMES[lang]}: "${firstMessage}"`,
      });
      return response.text?.trim().replace(/^["']|["']$/g, '') || "New Chat";
    } catch { return "New Chat"; }
  }
}
export const geminiService = new GeminiService();